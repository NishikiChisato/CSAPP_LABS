#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "getopt.h"
#include "cachelab.h"

int get_elem(int group, int tag);
void update_elem(int idx, int tag, int group);
int is_full(int tag, int group);
int LRU(int tag, int gruop);
void update(int addr);
void cache();
void init();
void usage();
int parse_arg(int argc, char* argv[]);



typedef struct 
{
    //tag和valid的值均源自地址，因此不需要考虑size
    int tag, vaild, timestamp;
} line;

int op = -1, verbose = 0, s = -1, E = -1, b = -1;
char* file_input = NULL;

line** set;

int hits = 0, misses = 0, evictions = 0;
int CurTime = 0;


int main(int argc, char* argv[])
{
    //printSummary(0, 0, 0);
    int res = parse_arg(argc, argv);
    if(res == -1) return -1;

    init();
    cache();
    printSummary(hits, misses, evictions);
    return 0;
}

int get_elem(int group, int tag)
{
    for(int i = 0; i < (1 << b); i ++)
    {
        if(set[group][i].vaild && set[group][i].tag == tag)
            return i;
    }
    return -1;
}

void update_elem(int idx, int tag, int group)
{
    //更新同组的其余时间戳
    for(int i = 0; i < E; i ++)
        if(set[group][i].vaild == 1) 
            set[group][i].timestamp++;
    //将该元素的时间戳清零，并将vaild置一
    set[group][idx].timestamp = 0;
    set[group][idx].vaild = 1;
    set[group][idx].tag = tag;
}

int is_full(int tag, int group)
{
    for(int i = 0; i < E; i ++)
    {
        if(set[group][i].vaild == 0)
            return i;
    }
    return -1;
}

int LRU(int tag, int gruop)
{
    int idx = 0, mx = -1;
    for(int i = 0; i < E; i ++)
    {
        if(set[gruop][i].timestamp > mx)
        {
            mx = i;
            idx = i;
        }
    }
    return idx;
}

void update(int addr)
{
    //int CO = addr & b;
    int CI = (addr >> b) & ((unsigned)(-1) >> (8 * sizeof(unsigned) - s));
    int CT = addr >> (s + b);

    int idx = get_elem(CI, CT);

    if(idx == -1)
    {
        int full = is_full(CT, CI);
        if(full != -1)
        {
            //有空余
            misses++;
            if(verbose) printf("miss\n");
            update_elem(full, CT, CI);
        }
        else
        {
            int k = LRU(CT, CI);
            evictions++;
            if(verbose) printf("evictions\n");
            update_elem(k, CT, CI);
        }
    }
    else
    {
        hits++;
        if(verbose) printf("hit\n");
        update_elem(idx, CT, CI);
    }
}

void cache()
{
    FILE* fp = fopen(file_input, "r");
    char str[20], op;
    int addr, size;
    while(fgets(str, 20, fp) != NULL)
    {
        if(str[0] == 'I') 
            continue;
        else sscanf(str, " %c %x,%d", &op, &addr, &size);
        //我们只需要看地址，size 没用，忽略
        if(op == 'S') update(addr);
        else if(op == 'L') update(addr);
        else update(addr), update(addr);
    }
}

void init()
{
    set = (line**)malloc((1 << s) * sizeof (line*));
    for(int i = 0; i < (1 << s); i ++)
        set[i] = (line*)malloc(E * sizeof (line));
    for(int i = 0; i < (1 << s); i ++)
    {
        for(int j = 0; j < E; j ++)
        {
            set[i][j].tag = -1;
            set[i][j].vaild = 0;
            set[i][j].timestamp = 0;
        }
    }
}

void usage()
{
    printf("Usage: ./csim-ref [-hv] -s <num> -E <num> -b <num> -t <file>\n");
    printf("-h: Optional help flag that prints usage info\n");
    printf("-v: Optional verbose flag that displays trace info\n");
    printf("-s <s>: Number of set index bits (S = 2s is the number of sets)\n");
    printf("-E <E>: Associativity (number of lines per set)\n");
    printf("-b <b>: Number of block bits (B = 2b is the block size)\n");
    printf("-t <tracefile>: Name of the valgrind trace to replay\n");
}

int parse_arg(int argc, char* argv[])
{
    while((op = getopt(argc, argv, "h::v::s:E:b:t:")) != -1)
    {
        switch(op)
        {
            case 'h':
                usage();
                break;
            case 'v':
                verbose = 1;
                break;
            case 's':
                s = atoi(optarg);
                break;
            case 'E':
                E = atoi(optarg);
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 't':
                file_input = optarg;
                break;
            default:
                usage();
                return -1;
        }
    }
    return 0;
}




